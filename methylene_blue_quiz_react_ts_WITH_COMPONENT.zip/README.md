# Methylene Blue Quiz – React + TypeScript

This is a Vite React + TypeScript app with your exact component already in place.

## Run locally
npm i
npm run dev

## Build
npm run build

## Netlify
Connect the repo and use:
- Build command: npm run build
- Publish directory: dist
